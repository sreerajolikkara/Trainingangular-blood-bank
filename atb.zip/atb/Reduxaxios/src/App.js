import React from 'react';
import Menu from './Menu/Menu.react';
import './App.css';

function App() {
  return (
    <div className="App">
      <Menu></Menu>
    </div>
  );
}

export default App;
