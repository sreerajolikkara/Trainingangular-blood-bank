 const reducer = (state ={
    title:"Login"
} , action) => {
    switch (action.type) {
        case 'LOGOUT':
            return Object.assign({},action);
        case 'LOGIN':
            return Object.assign({},action);
        default:
            return state
    }
}
export default reducer;