import React from 'react';
import Login from '../Login/Login.react';
import store,{login,logout} from '../store';
import {connect} from 'react-redux';



class Menu extends React.Component {
    
    render() {
        if(this.props.title === 'Login')
        {
        return (
            <div >
                
                <Login    action ={this.props.out}></Login>

            </div>
        );
        }
        else
        {
            return (
                <div >
                    
                    <Login  title ={this.props.title}  action ={this.props.in}></Login>
    
                </div>
            );
        }
    }
}
 const mapDispatchToProps = (dispatch) => {
    return {
        in: () => {
            dispatch(login);
        },
        out:()=>{
            dispatch(logout);
        }
    }
}
const  mapStateToProps = (state) => {
    return {
        title: state.title
    }
}
 export default connect(mapStateToProps, mapDispatchToProps)(Menu);