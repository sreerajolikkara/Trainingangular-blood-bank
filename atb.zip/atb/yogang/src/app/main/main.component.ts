import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  lst = []

  name;
  city;

  showApi;

  result;

  flag;
  displayObj;

  constructor(private service: PostService) { }

  ngOnInit() {

    this.lst = [
      { id: 101, name: "Aj" },
      { id: 102, name: "Cheenu" }
    ]

    this.service.getPost().subscribe(
      data => (this.result = data)
    )
  }

  display(index) {
    this.flag = !this.flag
    this.displayObj = this.lst[index]
  }


  getPosts() {
    this.showApi = !this.showApi
  }

  postData(){
    this.service.postData({name:this.name, city:this.city})
      .subscribe(
        data => console.log(data)
      )
  }

}
