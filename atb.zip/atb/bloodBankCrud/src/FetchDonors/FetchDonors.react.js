import React from 'react';
import Datagrid from '../Datagrid/Datagrid.react';
import AddDonor from '../AddDonor/AddDonor.react';



class FetchDonors extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            donorList :[]
        }
    }
     url="http://localhost:3001/bloodDonors";
    componentDidMount()
    {
        

        fetch(this.url).then(response => response.json()).then(donorList => this.setState({donorList}))  ;
        
    }
 //   url="http://localhost:3001/bloodDonors";
   
    render() {
        return (
            <div >

                    <AddDonor donorList ={this.state.donorList}></AddDonor>
            </div>
        );
    }
}

export default FetchDonors;