import React from 'react';



const Footer2 = () => {

    return (
        <div >
          <a href="http://facebook.com">
              <span className="fa fa-facebook-official fa-3x"></span>
              <br/>
              <table>
                  <tr>
                      <th>Private</th>
                      <th>Connect</th>
                  </tr>
                  <tr>
                      <td>Malar Hospital</td>
                      <td>< a href="http://facebook.com" className="fa fa-facebook-official fa-3x"></a></td>
                  </tr>
                  <tr>
                      <td>Appolo  Hospital</td>
                      <td>< a href="http://facebook.com" className="fa fa-facebook-official fa-3x"></a></td>
                  </tr>
                  <tr>
                      <td>Miot Hospital</td>
                      <td>< a href="http://facebook.com" className="fa fa-facebook-official fa-3x"></a></td>
                  </tr>
              </table>
          </a>
        </div>
    );

}

export default Footer2;