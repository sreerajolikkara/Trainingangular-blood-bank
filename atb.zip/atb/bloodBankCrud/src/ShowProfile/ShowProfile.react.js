import React from 'react';
import { isTemplateElement } from '@babel/types';



class ShowProfile extends React.Component {
    url="https://api.github.com/search/repositories?q=topic:Python&sort=stars&order=desc";
    constructor(props) {
        super(props);
        this.state={
           profile:{},
           loaded:false
        }
    }
    componentDidMount()
    {
    fetch(this.url).then(data=>data.json()).then(profile=>{this.setState({profile,loaded:true})});
    
    }

    render() {
        if(!this.state.loaded)
         {    
        return(
            <div className='showprofile_wrapper'>
                 <h1>Loading....</h1>
            </div>
        );
         }
         else
         {
            console.log(this.state.loaded+ "HI" );
            return (
                <div >
                    {
                        this.state.profile.items.map((item,index)=>
                        (
                            <div key={index.id}>{item.name}
                            <img  src={item.owner.avatar_url} alt="Image"></img>
                            <div>{item.name}</div>
                            <div>{item.forks}</div>
                            <div>{item.stargazers_count}</div>
                            <div>{item.open_issues}</div></div>
                        ))
                    }
                </div>
            );
         }
                   
   

    }
}

export default ShowProfile;