import React from 'react';
import Datagrid from '../Datagrid/Datagrid.react';
import PropTypes from 'prop-types';

let donorName="Ramesh";
let donorList=[{donorName:'Ramesh',phoneNumber:67897,bloodGroup:"O+ve",donationCount:45},{donorName:'Suresh',phoneNumber:56784,bloodGroup:"O-ve",donationCount:45},{donorName:'Ram',phoneNumber:67897,
bloodGroup:"A+ve",donationCount:95}];
const ShowDonor = (props) => {

    return (
        <div >
            <h1 className='text-center'>{props.title}</h1>
            <Datagrid donorList={donorList}>
               <thead>
                   <tr>
                   <th>DonorName</th>
                    <th>PhoneNumber</th>
                    <th>BloodGroup</th>
                    <th>DonationCount</th>

                   </tr>
               </thead>


                </Datagrid> 
            </div>
    );

}
ShowDonor.propTypes={
    title: PropTypes.string.isRequired
};

export default ShowDonor;