import React from 'react';






let url="http://localhost:3001/bloodDonors";
class AddDonor extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            newDonor:{
                id: 102,
                donorName: "",
                bloodGroup: "",
                lastDonated: ""
            },
            donorList :this.props.donorList
           
        }
        //console.log(this.props.donorList);
    }

    componentDidMount() {
        console.log("=======================");
        this.call();
    }
    handleSubmit= (event)=>{
            event.preventDefault();
            console.log("Submit Function Called");
            document.getElementById("myid").setAttribute("enabled",true);
            document.getElementById("myid").type="visible";
            document.getElementById("donorName").type="visible";
            document.getElementById("bloodGroup").type="visible";
            document.getElementById("lastDonated").type="visible";
           
        //    this.visiblitEvent("POST");
           
       
            fetch(url,{"method":"POST",
                        "body":JSON .stringify(this.state.newDonor),
                        "headers":{
                            "Content-Type":"application/json"
                        }
        }).then(resp=>{ console.log('Resource Created');this.call()});
        this.refs.name.value="";
        this.refs.donorName.value='';
        this.refs.bloodGroup.value='';
        this.refs.lastDonated.value='';
        console.log(this.state.donorList);
        

    }
    // handleRemove = id => event => {
    //     // Do stuff with id and event
    //   }
      
      

    visiblitEvent=pid=>event=>
    {
        console.log(pid);
        document.getElementById("myid").type="visible";
        document.getElementById("myid").value=pid;
     //   document.getElementById("myid").setAttribute("disabled",true);
        document.getElementById("donorName").type="visible";
        document.getElementById("bloodGroup").type="visible";
        document.getElementById("lastDonated").type="visible";
        document.getElementById("edit").removeAttribute("hidden");
      //  this.handlePut(pid);
    }

    handlePut=sentValue=> event=>{
        event.preventDefault();
        console.log("PUT Function Called"+sentValue);
     //  this.visiblitEvent();
       let id=this.refs.name.value;
       console.log(id);
   
        fetch(url+"/"+id,{"method":"PUT",
                    "body":JSON .stringify(this.state.newDonor),
                    "headers":{
                    "Content-Type":"application/json"
                    }
    }).then(resp=>{ console.log('Resource Created');this.call()});
    this.refs.name.value="";
    this.refs.donorName.value='';
    this.refs.bloodGroup.value='';
    this.refs.lastDonated.value='';
   // console.log(this.state.donorList);
    

}
handleDelete=pid=> event=>{
    event.preventDefault();
    console.log("DELETE Function Called"+pid);
 //  this.visiblitEvent();
   let id=this.refs.name.value;
   console.log(id);

    fetch(url+"/"+pid,{"method":"DELETE",
                "body":JSON .stringify(this.state.newDonor),
                "headers":{
                "Content-Type":"application/json"
                }
}).then(resp=>{ console.log('Resource Created');this.call()});
this.refs.name.value="";
this.refs.donorName.value='';
this.refs.bloodGroup.value='';
this.refs.lastDonated.value='';
// console.log(this.state.donorList);


}



    call = ()=>{
        fetch(url).then(response => response.json()).then(donorList => this.setState({donorList}))  ;
        console.log(this.state.donorList);
    }

    handleChange =(event) =>{
      let name =event.target.name;
        let value =event.target.value;
        this.setState(prevState =>( {newDonor:{...prevState.newDonor,[name]:value}}));
    }
   

    render() {
    //   console.log(i);
    //   i+=1;
  //  console.log(this.props.donorList)
             // this.state.donorList=this.props.donorList;
        return (
            <div >
                <form onSubmit ={this.handleSubmit}>
                    <label htmlFor="">Id</label>
                    <input type="text" name='id' id="myid" ref="name"type="hidden" onChange={this.handleChange} />
                    <label htmlFor="">Name</label>
                    <input type="text" name="donorName" id="donorName" ref="donorName" type="hidden" onChange={this.handleChange}/>
                    <label htmlFor="">BloodGroup</label>
                    <input type="text" name="bloodGroup" ref="bloodGroup" id="bloodGroup"type="hidden"onChange={this.handleChange}/>
                    <label htmlFor="">Last Donated</label>
                    <input type="date" name="lastDonated" ref="lastDonated" id="lastDonated"type="hidden"onChange={this.handleChange}/>
                    <button onClick={this.handlePut("PUT")} id="edit" hidden>UPDATE</button>
                    <button onClick={this.visiblitEvent()} id="delete">POST</button>

                    <input type="submit" value="SUBMIT"/>
                </form>
                <table className='table table-striped'>
               
                <tbody>
                    {
                         this.state.donorList.map((name,index)=>
                        {
                             return <tr key={index}>
                                 <td>{name.id}</td>
                                 <td>{name.donorName}</td>            
                                <td>{name.bloodGroup}</td>
                                <td>{name.lastDonated}</td>
                                <td><button onClick={this.visiblitEvent(name.id)}>Update</button></td>
                                <td><button onClick={this.handleDelete(name.id)}>Delete</button></td>
                             </tr>
                        })
                    }
                
               
                </tbody>
               
            </table>

            </div>
        );
        
    }
}

export default AddDonor;