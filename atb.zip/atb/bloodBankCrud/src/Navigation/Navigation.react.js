import React from 'react';
import {Route,Switch} from 'react-router-dom';
import Content from '../Content/Content.react';
import FetchDonors from '../FetchDonors/FetchDonors.react';
import AddDonor from '../AddDonor/AddDonor.react';
import Blog from '../Blog/Blog.react';


const Navigation = () => {

    return (
        <div >
            <main>
                <switch>
                    <Route exact path="/" component={Content}></Route>
                    <Route path="/fetch" component={FetchDonors}></Route>
                    
                    <Route path='/blog'component={Blog}></Route>
                </switch>
            </main>
        </div>
    );

}

export default Navigation;