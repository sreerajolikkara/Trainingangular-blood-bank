import React from 'react';
import ShowDonor from '../ShowDonor/ShowDonor.react';
import Search from '../Search/Search.react';
import Blog from '../Blog/Blog.react';
import FetchDonors from '../FetchDonors/FetchDonors.react';
import AddDonor from '../AddDonor/AddDonor.react';
import LifeCycle from '../LifeCycle/LifeCycle.react';
import ShowCOntent from '../ShowCOntent/ShowCOntent.react';
import Opos from '../Opos.png';
import ShowProfile from '../ShowProfile/ShowProfile.react';
const request ={
    bloodGroup:'O+ve',
    requiredUnit:12,
    location:"Chennai",
    imageRef:Opos
  }

const Content = (props) => {

    return (
        <div >
            <h2>Current Request </h2>
        {/*   <h3>{props.request.location}</h3>
            
                <h4>{props.request.bloodGroup}</h4>
                <h4>{props.request.requiredUnit}</h4>
            
            <img src={props.request.imageRef} alt="IMAGE COME"></img>
    */}
    <ShowCOntent request={request}></ShowCOntent>
   
     
        
        </div>
    );

}

export default Content;