import React from 'react';
import FeedBack from '../FeedBack/FeedBack.react';



class Blog extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            likeCount:1,
            unlikeCount:1
        }
    }
    incrementLikes=()=>{
    
       return this.setState({likeCount:this.state.likeCount+1});
    }
    incrementDisLikes=()=>{
    
        return this.setState({unlikeCount:this.state.unlikeCount+1});
     }

    render() {
        console.log("Render called ");
        return (
            
            <div >
                <article>
                    <h1> Who can donate Blood?</h1>
                    <p>Blood donations in India are conducted by several organizations and hospitals by organizing blood donation camps. Donors can also visit blood banks in hospitals to
                         donate blood or directly to a receiver. Despite shortage of donated blood, efforts by the government and various organizations have led to a decrease in the 
                         demand and supply gap over the years. The number of voluntary blood donors increased from 54.4% in 2006–2007 to 83.1% in 2011–2012, with the number of blood units
                          increasing from 4.4 million units in 2006–2007 to 9.3 million units in 2012–2013.[1] In 2016, the Ministry of Health and Family Welfare reported a donation of
                           10.9 million units against a requirement of 12 million units.
                    </p>
                </article>
                <p><span>Likes :</span>{this.state.likeCount}</p>
                <p><span>DisLikes :</span>{this.state.unlikeCount}</p>
                <FeedBack action={this.incrementLikes} dislikeaction={this.incrementDisLikes}></FeedBack>
            </div>
        );
    }
}

export default Blog;
