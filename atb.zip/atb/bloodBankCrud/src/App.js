import React from 'react';
import './App.css';
import Footer from './Footer/Footer.react';
import Footer2 from './Footer2/Footer2.react';
import Content from './Content/Content.react';

import Navigation from './Navigation/Navigation.react';
import ShowProfile from './ShowProfile/ShowProfile.react';
import Search from './Search/Search.react';


function App() {
  return (
    <div className="App">
      <Footer>

      </Footer>
      <Navigation/>
      <ShowProfile></ShowProfile>
      <Search></Search>
      
    </div>
  );
}

export default App;
