import React from 'react';



const ShowCOntent = (props) => {

    return (
        <div >
 <h3>{props.request.location}</h3>
            
            <h4>{props.request.bloodGroup}</h4>
            <h4>{props.request.requiredUnit}</h4>
        
        <img src={props.request.imageRef} alt="IMAGE COME"></img>
        </div>
    );

}

export default ShowCOntent;