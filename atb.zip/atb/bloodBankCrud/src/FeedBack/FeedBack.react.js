import React from 'react';



const FeedBack = (props) => {

    return (
        <div >
             <button className="fa fa-thumbs-up" onClick={props.action} >Likes</button>
             <button className="fa fa-thumbs-down"  onClick={props.dislikeaction}>Dislikes</button>
        </div>
    );

}

export default FeedBack;