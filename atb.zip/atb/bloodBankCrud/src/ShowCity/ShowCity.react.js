import React from 'react';


const ShowCity = (props) => {
 console.log("SHow City Called");
    return (
        <div >
            <h2>{props.city}</h2>
        </div>
    );

}

export default ShowCity;