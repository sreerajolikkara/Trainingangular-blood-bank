import React from 'react';
import ReactDOM from 'react-dom';
import ShowCity from '../ShowCity/ShowCity.react';



class LifeCycle extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            name:"Ramesh",
            city:"Chennai"
        };
        console.log("Constructor CALLED ====");
    }
    componentDidMount()
    {
        console.log("DID MOUNT CALLED ====");
        
        const element=ReactDOM.findDOMNode(this);
        const child=element.firstChild;
        ReactDOM.render("Ram",child);
      
    }
    change=()=>
    {
        console.log("Update Change fired");
        this.setState({name:this.state.name+'ji',city:"Mumbai"});
    }
    shouldComponentUpdate()
    {
        return true;
    }
    componentDidUpdate()
    {
        console.log("Component Did Update Fired");

    }

    render() {
        console.log("Render Method CALLED ====");
       
        return (
            <div >
                <h2>{this.state.name}</h2>
                <ShowCity city={this.state.city}></ShowCity>
                <button onClick={this.change}>Update</button>
               
            </div>
        );
    }
}

export default LifeCycle;