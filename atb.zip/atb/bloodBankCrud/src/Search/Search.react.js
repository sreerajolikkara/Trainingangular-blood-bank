import React from 'react';

const clear =(msg) =>{
    console.log('Clear Invoked');

    return ()=>
    {
        console.log('Inner function called '+ msg);
    }
}

const Search = () => {

    return (
        <div >
            <button className="fa fa-search" onClick={(event)=>{console.log(event)}}>Search</button>   {/* Inline Function calling using arrow function */}
            <button className="fa fa-crosshairs" onClick={clear}>Clear</button>                         {/* Calling a function without curly braces so that it  can  be  called a direct functiomn*/}
            <button className="fa fa-home" onClick={clear("Rameesh")}>Home</button>                              {/**/}
        </div>
    );

}

export default Search;
