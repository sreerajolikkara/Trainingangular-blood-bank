import React from 'react';
import ShowGreeeting from '../ShowGreeeting/ShowGreeeting.react';
import {valen, birth} from '../store';
import {connect} from 'react-redux'




class Greeter extends React.Component {
   
    
    render() {
        return (
            <div >
                <p>{this.props.message}</p>
                <ShowGreeeting action ={this.props.bday} label ="Birthday"></ShowGreeeting>
                <ShowGreeeting action ={this.props.vday} label ="Valentineday"></ShowGreeeting>
            </div>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        bday: () => {
            dispatch(birth);
        },
        vday:()=>{
            dispatch(valen);
        }
    }
}
const mapStateToProps=(state)=>{
   
        return{
            message  :state.message
        }
    
}
export default connect(mapStateToProps,mapDispatchToProps)(Greeter);
