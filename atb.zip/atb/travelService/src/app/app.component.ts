import { Component, Output } from '@angular/core';
import { Navigationlinks } from './navigationlinks';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Prashanth Travel Service';
  subHeading='Chennai';

 // links=['home','catolog','payment','contact'];
 links:Navigationlinks[]=[{'text':'Home',link:'/search'},
          {'text':'catolog',link:'/show'}];
 
}
