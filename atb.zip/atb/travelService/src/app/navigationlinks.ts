export interface Navigationlinks {
    link:string;
    text:string;
}
