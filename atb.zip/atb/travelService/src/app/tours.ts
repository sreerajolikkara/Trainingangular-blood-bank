export interface Tours {
    id:Number;
    tourism:string;
    price:Number;
}
